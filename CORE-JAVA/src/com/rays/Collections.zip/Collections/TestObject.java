package com.rays.Collections;

import java.util.ArrayList;

public class TestObject {

	public static void main(String[] args) {

		String s = "100";

		int a = 100;

		Object obj = s;

	}

}