package com.rays.Collection;

import java.util.*;

public class EqualHashCodeTest1 {
    public static void main(String[] args) {
        Map m = new HashMap();
    }
}
