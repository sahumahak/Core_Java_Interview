package com.rays.Collection;

public class A_Z_asciiValue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	for (char i = 'A'; i <='Z'; i++) {
		
		System.out.print((int)i + " ");
		
	}

	}

}