package com.rays.IOProgram;

import java.util.Scanner;

public class ScaanerClassExample {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		//Integer
		int a;
		System.out.println("Please Enter any Number....");
		a = sc.nextInt();
		System.out.println("Entered data is = " + a);
		
		//float
//		float a;
//		System.out.println("Please Enter any Float Number....");
//		a = sc.nextFloat();
//		System.out.println("Entered data is = " + a);
		
		
		
		//double
//		double a;
//		System.out.println("Please Enter any Double Number....");
//		a = sc.nextDouble();
//		System.out.println("Entered data is = " + a);
		
		
		
		//String
//		String a;
//		System.out.println("Please Enter any String Number....");
//		a = sc.nextLine();
//		System.out.println("Entered data is = " + a);
		
		
		//String without space
//		String a;
//		System.out.println("Please Enter any String Number....");
//		a = sc.next();
//		System.out.println("Entered data is = " + a);
	}

}
